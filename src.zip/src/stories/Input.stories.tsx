import React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { Input } from "../components/Input";
import { Icon } from "../components/Icon";

const meta: Meta<typeof Input> = {
  title: "Components/Input",
  component: Input,
  parameters: {
    layout: "padded",
    docs: {
      description: {
        component:
          "A versatile input field with multiple sizes, states, and icon support.",
      },
    },
  },
  argTypes: {
    size: {
      control: { type: "select" },
      options: ["xs", "sm", "md", "lg", "xl"],
    },
    state: {
      control: { type: "select" },
      options: ["default", "error", "disabled", "readonly"],
    },
    leftIcon: {
      control: { type: "boolean" },
    },
    rightIcon: {
      control: { type: "boolean" },
    },
  },
  tags: ["autodocs"],
} satisfies Meta<typeof Input>;

export default meta;
type Story = StoryObj<typeof Input>;

export const Default: Story = {
  args: {
    placeholder: "Enter your text...",
    size: "md",
    state: "default",
  },
};

export const Sizes: Story = {
  render: () => (
    <div className="space-y-6 max-w-md">
      {(["xs", "sm", "md", "lg", "xl"] as const).map((size) => (
        <div key={size} className="flex flex-col gap-2">
          <label className="text-sm font-medium text-gray-700">
            {size.toUpperCase()} Size
          </label>
          <Input size={size} placeholder={`Enter ${size} text...`} />
        </div>
      ))}
    </div>
  ),
};
export const States: Story = {
  render: () => (
    <div className="space-y-4 max-w-md">
      {(["default", "error", "disabled", "readonly"] as const).map((state) => (
        <Input
          key={state}
          state={state}
          placeholder={`${state.charAt(0).toUpperCase() + state.slice(1)} state`}
          defaultValue={
            state === "readonly" ? "This is read-only text" : undefined
          }
        />
      ))}
    </div>
  ),
};

export const WithIcons: Story = {
  render: () => (
    <div className="space-y-4 max-w-md">
      <Input
        leftIcon={<Icon name="search" size="sm" />}
        placeholder="Search with left icon..."
      />
      <Input
        rightIcon={<Icon name="cancel" size="sm" />}
        placeholder="Clearable with right icon..."
      />
      <Input
        leftIcon={<Icon name="mail" size="sm" />}
        rightIcon={
          <Icon name="check_circle" size="sm" className="text-green-500" />
        }
        placeholder="Email with both icons..."
      />
    </div>
  ),
};

export const Types: Story = {
  render: () => (
    <div className="space-y-4 max-w-md">
      <Input type="text" placeholder="Text input" />
      <Input type="email" placeholder="Email input" />
      <Input type="password" placeholder="Password input" />
      <Input type="number" placeholder="Number input" />
      <Input type="tel" placeholder="Phone number" />
      <Input type="url" placeholder="Website URL" />
    </div>
  ),
};

export const FullWidth: Story = {
  render: () => (
    <div className="space-y-4">
      <Input fullWidth placeholder="Full width input" />
      <Input
        fullWidth
        leftIcon={<Icon name="search" size="sm" />}
        placeholder="Full width with icon"
      />
    </div>
  ),
};

export const Playground: Story = {
  args: {
    placeholder: "Play with controls...",
    size: "md",
    state: "default",
    fullWidth: false,
  },
  argTypes: {
    leftIcon: {
      mapping: {
        false: undefined,
        true: <Icon name="search" size="sm" />,
      },
    },
    rightIcon: {
      mapping: {
        false: undefined,
        true: <Icon name="check_circle" size="sm" />,
      },
    },
  },
};
